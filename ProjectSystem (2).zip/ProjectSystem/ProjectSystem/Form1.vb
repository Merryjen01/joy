﻿Imports System.IO

Public Class Form1

    Property Id As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDatagrid()
    End Sub
    Sub LoadDatagrid()
        Using db As New Model1
            Dim a = (From s In db.Users Where s.Fullname.StartsWith(TextBox5.Text) Or s.Username.StartsWith(TextBox5.Text) Select New With {
                   .id = s.Id, .Username = s.Username, .Password = s.Password, .Fullname = s.Fullname, .Address = s.Address, .DateCreated = s.DateCreated}).ToList

            With DataGridView1
                .DataSource = a
            End With
            DataGridView1.Columns.Item(0).Visible = False
        End Using
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        LoadDatagrid()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        With OpenFileDialog1
            .Filter = "JPEGs|*.jpg|PNGs|*.png|GIFs|*.gif|BITMAPS|*bmp"
            .FilterIndex = 1
        End With
        Dim a As DialogResult = OpenFileDialog1.ShowDialog
        If (a = DialogResult.OK) Then
            If (OpenFileDialog1.FileName.CompareTo("") <> 0) Then
                Dim ThisImage = Image.FromFile(OpenFileDialog1.FileName)
                PictureBox1.BackgroundImage = ThisImage
            End If
        End If
    End Sub
    Public Function ImgtoByte(MyImage As Image) As Byte()
        Dim ImageBytes(0) As Byte
        Using mstream As New MemoryStream()
            MyImage.Save(mstream, MyImage.RawFormat)
            ImageBytes = mstream.ToArray()
        End Using
        Return ImageBytes
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Using db As New Model1
            If Id <= 0 Then
                Dim a = New User
                With a
                    .UserImage = ImgtoByte(PictureBox1.BackgroundImage)
                    .Username = TextBox1.Text
                    .Password = TextBox2.Text
                    .Fullname = TextBox3.Text
                    .Address = TextBox4.Text
                    .DateCreated = Now.Date
                End With
                db.Users.Add(a)
                If db.SaveChanges Then
                    MsgBox("save!")
                    LoadDatagrid()
                    LoadClear()
                Else
                    MsgBox("Error!")
                End If

            Else
                Dim b = (From s In db.Users Where s.Id = Id).FirstOrDefault
                With b
                    .UserImage = ImgtoByte(PictureBox1.BackgroundImage)
                    .Username = TextBox1.Text
                    .Password = TextBox2.Text
                    .Fullname = TextBox3.Text
                    .Address = TextBox4.Text
                    .DateCreated = Now.Date
                End With

                If db.SaveChanges Then
                    MsgBox("save!")
                    LoadDatagrid()
                    LoadClear()
                    Id = 0
                Else
                    MsgBox("Error!")
                End If

            End If

        End Using
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        LoadClear()
    End Sub
    Sub LoadClear()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        PictureBox1.BackgroundImage = My.Resources.PNGUserpic

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Id = DataGridView1.SelectedRows(0).Cells(0).Value
        Using db As New Model1
            Dim a = (From s In db.Users Where s.Id = Id).FirstOrDefault
            With a
                If (.UserImage IsNot Nothing) Then
                    Dim mstream As MemoryStream = New MemoryStream(.UserImage)
                    Dim thisImgLoc = Image.FromStream(mstream)
                    PictureBox1.BackgroundImage = thisImgLoc
                Else
                    PictureBox1.BackgroundImage = My.Resources.PNGUserpic
                End If
                TextBox1.Text = .Username
                TextBox2.Text = .Password
                TextBox3.Text = .Fullname
                TextBox4.Text = .Address
            End With
        End Using
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Using db As New Model1
            Dim a = (From s In db.Users Where s.Id = Id).FirstOrDefault
            db.Users.Remove(a)
            If db.SaveChanges Then
                MsgBox("Removed!")
                LoadClear()
                LoadDatagrid()
                Id = 0
            Else
                MsgBox("Error!")
            End If
        End Using
    End Sub
End Class

